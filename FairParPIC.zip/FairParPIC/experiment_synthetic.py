"""
Synthetic, naturally directed networks with weak-to-strong group signal:
ParPIC vs. Fair ParPIC with the Euclidean projector Pi_F (the paper's method)
vs. Fair ParPIC with the pi-orthogonal projector Pi_pi.

Every network is a directed stochastic block model (no k-NN graph, no
features). Vertices arrive over time and an edge i -> j is more likely when j
arrived before i, so W != W^T by construction. The edge probability is

    p(i -> j) = scale * base(i, j) * direction(i, j) * popularity(j)

    base:  same cluster, same group    P_IN  * (1 + h)
           same cluster, other group   P_IN  * (1 - h)
           other cluster, same group   P_OUT * (1 + h)
           other cluster, other group  P_OUT * (1 - h)

The GROUP SIGNAL h in [0, 1) is the only thing that changes within a network
type: h = 0 means the protected groups play no role in the links; as h grows,
vertices link preferentially inside their own group, and for h > 2/3 a
same-group link ACROSS clusters is more likely than a cross-group link
INSIDE a cluster (the groups become the dominant community structure).

Three network types:
  A  "citation":  n = 10000, 5 equal clusters, 2 groups (30/70), every cluster
     has the population group shares (the planted clustering is fair),
     90% of the edge mass points to earlier vertices.
  B  "popularity": n = 8000, 8 clusters of unequal size, 3 groups (15/35/50),
     heavy-tailed popularity of the cited vertex (Pareto, in-degrees are
     heavy-tailed), 90% forward edges.
  C  "hyperlink": n = 6000, 4 equal clusters, 2 groups (30/70 overall) spread
     UNEVENLY over the clusters (minority share 15%, 25%, 35%, 45%), so the
     planted clustering itself is not fair; 70% forward edges (more
     reciprocity).

For each network: balance of ParPIC + k-means, Fair ParPIC (Pi_F), Fair
ParPIC (Pi_pi); also Stage 1 alone, price of fairness and ARI to the planted
clusters. k = number of planted clusters, delta = 0.05, gamma = 0.5.
Fully self-contained; one run per network (seed 42).
Run a subset with  TYPES=A,B LEVELS=none,strong python3 experiment_synthetic.py
Output: results/synthetic_suite.json
"""

import json
import os
import time

import numpy as np
import scipy.sparse as sp
from scipy.optimize import Bounds, LinearConstraint, linear_sum_assignment, milp
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score

# ======================================================================
# Settings
# ======================================================================
SEED = 42
GAMMA = 0.5
DELTA = 0.05
T_MAX = 40
MAX_ALTERNATIONS = 10
P_IN, P_OUT = 0.030, 0.006            # at n = 3000; scaled by 3000 / n
SIGNALS = {"none": 0.0, "weak": 0.3, "moderate": 0.6, "strong": 0.9}

NETWORKS = {
    "A citation": dict(
        n=10000, cluster_shares=[0.2] * 5,
        group_shares=[[0.3, 0.7]] * 5, q_forward=0.9, pareto=None),
    "B popularity": dict(
        n=8000, cluster_shares=[0.25, 0.20, 0.15, 0.12, 0.10, 0.08, 0.06, 0.04],
        group_shares=[[0.15, 0.35, 0.50]] * 8, q_forward=0.9, pareto=2.5),
    "C hyperlink": dict(
        n=6000, cluster_shares=[0.25] * 4,
        group_shares=[[0.15, 0.85], [0.25, 0.75], [0.35, 0.65], [0.45, 0.55]],
        q_forward=0.7, pareto=None),
}


# ======================================================================
# 1. Directed network generator
# ======================================================================
def directed_network(n, cluster_shares, group_shares, q_forward, pareto, h):
    rng = np.random.default_rng(SEED)
    sizes = np.round(np.array(cluster_shares) * n).astype(int)
    sizes[0] += n - sizes.sum()
    cluster = np.repeat(np.arange(len(sizes)), sizes)
    group = np.empty(n, dtype=int)
    for c, size in enumerate(sizes):                # group shares inside cluster c
        counts = np.round(np.array(group_shares[c]) * size).astype(int)
        counts[-1] += size - counts.sum()
        group[cluster == c] = rng.permutation(np.repeat(np.arange(len(counts)), counts))
    arrival = rng.permutation(n)
    popularity = np.ones(n)
    if pareto is not None:                          # heavy-tailed attractiveness, mean 1
        popularity = rng.pareto(pareto, n) + 1
        popularity /= popularity.mean()
    scale = 3000 / n

    rows, cols = [], []
    for start in range(0, n, 1000):                 # row blocks keep memory small
        i = np.arange(start, min(start + 1000, n))
        same_c = cluster[i, None] == cluster[None, :]
        same_g = group[i, None] == group[None, :]
        base = np.where(same_c, P_IN, P_OUT) * np.where(same_g, 1 + h, 1 - h)
        direction = np.where(arrival[None, :] < arrival[i, None], 2 * q_forward, 2 * (1 - q_forward))
        prob = np.minimum(scale * base * direction * popularity[None, :], 1.0)
        hit = rng.random(prob.shape) < prob
        hit[np.arange(len(i)), i] = False           # no self-loops
        r, c = np.nonzero(hit)
        rows.append(i[r]); cols.append(c)
    W = sp.csr_matrix((np.ones(sum(len(r) for r in rows)),
                       (np.concatenate(rows), np.concatenate(cols))), shape=(n, n))
    W = sp.lil_matrix(W)
    for i in np.where(np.asarray(W.sum(axis=1)).ravel() == 0)[0]:   # no dangling vertices
        cand = np.where((cluster == cluster[i]) & (np.arange(n) != i))[0]
        W[i, rng.choice(cand)] = 1
    return sp.csr_matrix(W), cluster, group


# ======================================================================
# 2. Stage 1: operator, diffusion time, embeddings
# ======================================================================
def find_knee(x, y):
    """Point of maximum distance to the chord joining the curve's endpoints."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    if y.max() - y.min() < 1e-12:
        return int(x[0])
    xn = (x - x.min()) / (x.max() - x.min())
    yn = (y - y.min()) / (y.max() - y.min())
    num = np.abs((yn[-1] - yn[0]) * xn - (xn[-1] - xn[0]) * yn
                 + xn[-1] * yn[0] - yn[-1] * xn[0])
    return int(x[int(np.argmax(num))])




def p_rw_operator(W, gamma):
    """Natural random walk P = D_out^-1 W of the digraph -> ParPIC's reversible
    operator P_(nu); also returns pi = nu + xi, w.r.t. which it is reversible."""
    d_out = np.asarray(W.sum(axis=1)).ravel()
    d_in = np.asarray(W.sum(axis=0)).ravel()
    P = sp.diags(1.0 / d_out) @ W
    nu = np.maximum(gamma * d_in / d_in.sum() + (1 - gamma) * d_out / d_out.sum(), 1e-12)
    xi = np.asarray(nu @ P).ravel()
    pi = nu + xi
    P_nu = sp.csr_matrix(sp.diags(1.0 / pi) @ (sp.diags(nu) @ P + P.T @ sp.diags(nu)))
    return P_nu, pi


def diffusion_time(P_nu, t_max, n_probes):
    """Knee of the row-wise operator entropy H(t), estimated on probe rows."""
    n = P_nu.shape[0]
    probe = np.random.default_rng(SEED).choice(n, size=min(n_probes, n), replace=False)
    V = sp.csr_matrix((np.ones(len(probe)), (np.arange(len(probe)), probe)),
                      shape=(len(probe), n))
    H = []
    for _ in range(t_max):
        V = V @ P_nu
        Vd = V.toarray()
        H.append(sum(-np.sum(r[r > 1e-15] * np.log(r[r > 1e-15])) for r in Vd))
    return find_knee(np.arange(1, t_max + 1), H)




def three_embeddings(P_nu, pi, group_ids, G):
    n = P_nu.shape[0]
    d = int(np.ceil(np.sqrt(n)))
    t_star = diffusion_time(P_nu, T_MAX, d)
    alpha = np.bincount(group_ids, minlength=G) / n
    F = np.column_stack([(group_ids == j) - alpha[j] for j in range(G - 1)]).astype(float)
    FtF_inv = np.linalg.inv(F.T @ F)
    DiF = F / pi[:, None]                               # D_pi^-1 F
    FtDiF_inv = np.linalg.inv(F.T @ DiF)

    def project_euclid(M):                              # Pi_F M
        return M - F @ (FtF_inv @ (F.T @ M))

    def project_pi(M):                                  # Pi_pi M
        return M - DiF @ (FtDiF_inv @ (F.T @ M))

    Z0 = np.random.default_rng(SEED).standard_normal((n, d))
    Z_parpic, Z_F, Z_pi = Z0.copy(), Z0.copy(), Z0.copy()
    for _ in range(t_star):
        Z_parpic = P_nu @ Z_parpic
        Z_F = project_euclid(P_nu @ Z_F)
        Z_pi = project_pi(P_nu @ Z_pi)
    return Z_parpic, Z_F, Z_pi, t_star, F


# ======================================================================
# 3. Stage 2: fair assignment (LP relaxation -> count rounding ->
#    per-group transportation), inside alternating fair k-means
# ======================================================================
def fair_assignment(Z, centers, group_ids, G, alpha, delta):
    n, k = Z.shape[0], centers.shape[0]
    cost = ((Z[:, None, :] - centers[None, :, :]) ** 2).sum(axis=2)
    cost = cost / cost.mean()
    lower = (1 - delta) * alpha
    upper = np.minimum(alpha / (1 - delta), 1.0)

    # Step 1: LP relaxation of the fair assignment problem
    rows = list(np.repeat(np.arange(n), k))
    cols = list(np.arange(n * k))
    vals = [1.0] * (n * k)
    lb, ub, r = [1.0] * n, [1.0] * n, n
    for c in range(k):
        var = np.arange(n) * k + c
        for g in range(G):
            in_g = (group_ids == g).astype(float)
            for coef, lo, hi in [(in_g - lower[g], 0.0, np.inf),
                                 (in_g - upper[g], -np.inf, 0.0)]:
                rows += [r] * n; cols += list(var); vals += list(coef)
                lb.append(lo); ub.append(hi); r += 1
        rows += [r] * n; cols += list(var); vals += [1.0] * n
        lb.append(1.0); ub.append(np.inf); r += 1
    A = sp.csr_matrix((vals, (rows, cols)), shape=(r, n * k))
    lp = milp(cost.ravel(), constraints=LinearConstraint(A, lb, ub),
              integrality=np.zeros(n * k), bounds=Bounds(0, 1))
    x_frac = lp.x.reshape(n, k)
    m_tilde = np.vstack([x_frac[group_ids == g].sum(axis=0) for g in range(G)])

    # Step 2: integer counts m[g, c] closest to the fractional counts
    nv = G * k
    R, C, V, L2, U2 = [], [], [], [], []

    def add(coefs, lo, hi):
        row = len(L2)
        for j, v in coefs:
            R.append(row); C.append(j); V.append(v)
        L2.append(lo); U2.append(hi)

    n_g = np.bincount(group_ids, minlength=G)
    for g in range(G):
        add([(g * k + c, 1.0) for c in range(k)], n_g[g], n_g[g])
    for c in range(k):
        for g in range(G):
            add([(h * k + c, float(h == g) - lower[g]) for h in range(G)], 0, np.inf)
            add([(h * k + c, float(h == g) - upper[g]) for h in range(G)], -np.inf, 0)
        add([(g * k + c, 1.0) for g in range(G)], 1, np.inf)
    for j in range(nv):                          # t_j >= |m_j - m~_j|
        g, c = divmod(j, k)
        add([(nv + j, 1.0), (j, -1.0)], -m_tilde[g, c], np.inf)
        add([(nv + j, 1.0), (j, 1.0)], m_tilde[g, c], np.inf)
    A2 = sp.csr_matrix((V, (R, C)), shape=(len(L2), 2 * nv))
    cnt = milp(np.r_[np.zeros(nv), np.ones(nv)], constraints=LinearConstraint(A2, L2, U2),
               integrality=np.r_[np.ones(nv), np.zeros(nv)], bounds=Bounds(0, np.inf))
    m = np.rint(cnt.x[:nv]).astype(int).reshape(G, k)

    # Step 3: per-group transportation problems, solved exactly as a linear
    # assignment of the group's vertices to m[g, c] "slots" of every cluster
    # (same optimum as the transportation LP, much faster for large groups)
    labels = np.empty(n, dtype=int)
    for g in range(G):
        idx = np.where(group_ids == g)[0]
        slots = np.repeat(np.arange(k), m[g])
        row, col = linear_sum_assignment(cost[idx][:, slots])
        labels[idx[row]] = slots[col]
    return labels


def fair_kmeans(Z, group_ids, G, k, delta):
    alpha = np.bincount(group_ids, minlength=G) / len(group_ids)
    centers = KMeans(n_clusters=k, n_init=10, random_state=SEED).fit(Z).cluster_centers_
    labels = None
    for _ in range(MAX_ALTERNATIONS):
        new = fair_assignment(Z, centers, group_ids, G, alpha, delta)
        if labels is not None and np.array_equal(new, labels):
            break
        labels = new
        centers = np.vstack([Z[labels == c].mean(axis=0) for c in range(k)])
    return labels


# ======================================================================
# 4. Metrics
# ======================================================================
def balance_objective(labels, group_ids):
    vals = []
    for c in np.unique(labels):
        in_c = labels == c
        for g in np.unique(group_ids):
            vals.append(np.sum(in_c & (group_ids == g)) / np.sum(in_c))
    return float(np.min(vals))


def wcss(Z, labels):
    return float(sum(((Z[labels == c] - Z[labels == c].mean(axis=0)) ** 2).sum()
                     for c in np.unique(labels)))


# ======================================================================
# 5. Main
# ======================================================================
def run_network(spec, h):
    W, cluster, group = directed_network(h=h, **spec)
    n = W.shape[0]
    K = len(spec["cluster_shares"])
    G = len(spec["group_shares"][0])
    alpha_min = float((np.bincount(group) / n).min())
    d_in = np.asarray(W.sum(axis=0)).ravel()
    rec = {"n": n, "K": K, "G": G, "edges": int(W.sum()), "alpha_min": alpha_min,
           "floor": (1 - DELTA) * alpha_min,
           "one_way_edges": float(1 - W.multiply(W.T).sum() / W.sum()),
           "max_in_degree": int(d_in.max()),
           "planted balance": balance_objective(cluster, group)}
    P_nu, pi = p_rw_operator(W, GAMMA)
    Z_parpic, Z_F, Z_pi, t_star, F = three_embeddings(P_nu, pi, group, G)
    rec["t_star"] = int(t_star)
    for tag, Z in [("ParPIC", Z_parpic), ("Pi_F", Z_F), ("Pi_pi", Z_pi)]:
        km = KMeans(n_clusters=K, n_init=10, random_state=SEED).fit_predict(Z)
        rec[f"{tag} km balance"] = balance_objective(km, group)
        rec[f"{tag} km ARI"] = float(adjusted_rand_score(cluster, km))
        if tag != "ParPIC":
            fa = fair_kmeans(Z, group, G, K, DELTA)
            w_km = wcss(Z, km)
            rec[f"{tag} FA balance"] = balance_objective(fa, group)
            rec[f"{tag} FA ARI"] = float(adjusted_rand_score(cluster, fa))
            rec[f"{tag} FA pof"] = (wcss(Z, fa) - w_km) / w_km
    return rec


if __name__ == "__main__":
    os.makedirs("results", exist_ok=True)
    out_path = "results/synthetic_suite.json"
    results = json.load(open(out_path)) if os.path.exists(out_path) else {}
    wanted = os.environ.get("TYPES")
    levels = os.environ.get("LEVELS")
    for name, spec in NETWORKS.items():
        if wanted and name[0] not in wanted.split(","):
            continue
        for level, h in SIGNALS.items():
            if levels and level not in levels.split(","):
                continue
            t0 = time.time()
            rec = run_network(spec, h)
            rec["seconds"] = round(time.time() - t0, 1)
            results = json.load(open(out_path)) if os.path.exists(out_path) else {}
            results[f"{name} | {level}"] = rec
            with open(out_path, "w") as fh:
                json.dump(results, fh, indent=2)
            print(f"{name:13s} {level:9s} n={rec['n']} edges={rec['edges']} one-way={100 * rec['one_way_edges']:.0f}% "
                  f"t*={rec['t_star']}  floor={rec['floor']:.4f}  planted={rec['planted balance']:.4f} | "
                  f"ParPIC {rec['ParPIC km balance']:.4f}  Fair(Pi_F) {rec['Pi_F FA balance']:.4f}  "
                  f"Fair(Pi_pi) {rec['Pi_pi FA balance']:.4f} | PoF {100 * rec['Pi_F FA pof']:.2f}% / "
                  f"{100 * rec['Pi_pi FA pof']:.2f}% | ARI {rec['ParPIC km ARI']:.2f} / {rec['Pi_F FA ARI']:.2f} / "
                  f"{rec['Pi_pi FA ARI']:.2f}  ({rec['seconds']}s)", flush=True)
